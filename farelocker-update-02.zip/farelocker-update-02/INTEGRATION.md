# FareLocker frontend, update 02: how to put it into the repo

This folder holds one frontend update for the `farelock/` Next.js app in the
FareLocker/Frontend repo. These instructions are written for Claude Code to
follow in that repo; a person can follow them too.

**It replaces update 01.** Everything update 01 contained is in here, changed
where the design moved on. Apply this one whether or not update 01 has been
applied; the steps cover both.

Every path below is relative to `farelock/` unless it starts with the name of
a folder in this update (`files/`, `patches/`, and so on).

## What it was built on, and what was not seen

It was built on `main` at commit `3c0badb`, with these files replaced by the
newer copies the team sent on 10 October (the "profile page context" bundle):
`app/account/page.tsx`, `app/layout.tsx`, `app/login/actions.ts`,
`components/SearchForm.tsx`, `components/TicketDemo.tsx`,
`components/TearTicket.tsx`, `components/account/LockList.tsx`,
`lib/account.ts`, `lib/api.ts`, `lib/auth.ts`, `lib/wallet.ts`.

Three things in the repo were **not** seen while building it. Read them
before you change anything near them, and tell the user what you find:

1. **The team's log in page** (`app/login/page.tsx`, or wherever
   `logIn` from `app/login/actions.ts` is used).
2. **The team's sign-up page.** `app/login/actions.ts` has a `register`
   action, so one probably exists. Find it by searching for where `register`
   is imported. Its address may not be `/signup`.
3. **The wallet pages** (`app/wallet/`) as they are now. This update does
   not change them.

## What the update does

1. **Log in** (`/login`) and **sign up** (`/signup`) with a small header
   (logo, one prompt, one button). Both forms post to the team's own `logIn`
   and `register` actions, show the sentence those actions return when they
   fail, and keep what was typed. Sign up has first name, last name, email,
   optional phone number and password.
2. **Twinkling stars** behind every page.
3. **Fare page**, three views picked by the member's lock on that fare:
   - no lock: as before, with "Book now" removed (FareLocker does not sell
     tickets);
   - an open lock: the chart marks the day it was bought and the locked fare,
     plus a lock timeline, lock terms, the lock's value now and the Exercise
     button with its confirmation;
   - an ended lock: a record of how it went. Nothing on that view buys or
     exercises anything.
4. **My locks** (`/locks`): three totals, a filter, one row per lock. An open
   lock that is worth something can be exercised from the row.
5. **Lock checkout** (`/checkout?fare=<id>`): what is being bought, what it
   costs, paid from the wallet. If the wallet cannot cover it, the button
   becomes "Add funds".
6. **Account page**: the "Add funds" pill is gone from the page's own header
   (it is in the site header), and an **Activity** card lists wallet
   transactions with a "Transaction type" drop-down (`recharge`, `lock_fee`,
   `payout`, `withdraw`). "Your locks" now reads from the same place as My
   locks.
7. **"How it works" is gone from the site header.** Links that went to
   `/how-it-works` go to sections of the landing page.
8. **A 404 page** with the site header and footer (route-groups option only).

This is frontend only. Locks, transactions, buying a lock and exercising one
are mock data or empty actions; every place the backend has to be connected
is marked with a comment and listed at the end. Log in, sign up, log out and
the wallet balance use the team's real code.

No packages were added. `package.json` does not change.

## Before changing anything

1. Work in `farelock/`. Make sure `git status` is clean and start a branch.
2. Make sure `node_modules` is there (`npm install` if not).
3. Record how the repo behaves now, so you can tell afterwards what this
   update changed:

   ```bash
   npx tsc --noEmit
   npm run lint
   npx next build
   ```

   When this update was built, lint reported 2 errors in
   `components/TearTicket.tsx` and nothing else. They are not this update's;
   leave them alone.

4. Find out which of these is true, because the steps below depend on it:

   - **Is update 01 already applied?** It is if `components/StarField.tsx`
     exists.
   - **Which way was it applied?** If `app/(site)/` exists, pages were moved
     into route groups (option A below). If `app/globals.css` ends with a
     rule mentioning `data-auth-header`, the no-move option (B) was used.

5. Check the files this update replaces. From `farelock/`, with `U` set to
   where this folder is:

   ```bash
   U=/path/to/farelocker-update-02
   grep -v '^#' "$U/expected-hashes.txt" | while read -r path ids; do
     have=""
     for candidate in "$path" "$(printf '%s' "$path" | sed 's#^app/#app/(site)/#')"; do
       have=$(git rev-parse -q --verify "HEAD:./$candidate" 2>/dev/null) && break
     done
     case " $ids " in
       *" $have "*) ;;
       *) if [ -z "$have" ]; then echo "MISSING: $path"; else echo "CHANGED: $path"; fi ;;
     esac
   done
   ```

   - A file that prints nothing is the version this update was built on (or
     update 01's version of it). Replace it with the copy in this update.
   - `CHANGED` means someone has edited it since. Do not overwrite it. Open
     `patches/<path>.diff`, which shows what this update changes in that file
     starting from the team's version, and make the same changes by hand
     around the newer work. Tell the user which files needed this.
   - `MISSING` means the file is not where it was. Find out where it went
     before going on.

6. If update 01 is applied, run the same loop over `update-01-hashes.txt`.
   Here `MISSING` is fine (update 01 was not applied, or that file was not
   part of the option used). `CHANGED` means someone edited one of update
   01's files: merge by hand as above, comparing against the copy in this
   update.

7. For every other new file (the tables below mark them NEW), check it does
   not already exist. If one does and it is not in `update-01-hashes.txt`,
   stop and tell the user: someone has built the same thing and the two need
   comparing by a person.

## Step 1: route groups, or no move

Log in, sign up and the lock checkout must not show the site header (logo,
search bar, nav). There are two ways to do that.

**A. Route groups (recommended).** Pages move into `app/(site)/`, which gets
the site header and footer from its own layout. Log in and sign up live in
`app/(auth)/`, the checkout in `app/(checkout)/`, and those get no site
header. Folder names in brackets are left out of the address, so every URL
stays the same. The cost: every page file moves once, so a teammate with an
open branch that touches `app/` gets rename conflicts on their next merge.

**B. No move.** Every page stays where it is and `app/layout.tsx` is not
touched. One rule in `app/globals.css` hides the site header on a page that
has its own. Nobody's branch is disturbed. The cost: the site header is still
built and sent for those pages and then hidden, and the link between the CSS
rule and the headers is easy to break without noticing.

If update 01 is already applied, use the option it used and do not ask.
Otherwise ask the user which they want before going on. Both were built and
checked in a browser.

## Step 2: copy the files that are the same either way

Copy everything in `files/` into `farelock/`, keeping the folders. Replace a
file only if the checks above said it is safe.

| File | | What it is |
|---|---|---|
| `components/auth/AuthHeader.tsx` | NEW | The small header for log in and sign up |
| `components/auth/AuthCard.tsx` | NEW | The card with the page heading |
| `components/auth/LogInForm.tsx` | NEW | Fields `identifier`, `password`. Takes the action as a prop. |
| `components/auth/SignUpForm.tsx` | NEW | Fields `first_name`, `last_name`, `email`, `phone_number`, `password` |
| `components/auth/authForm.ts` | NEW | Runs an auth action from a form and keeps what was typed |
| `components/auth/FormError.tsx` | NEW | The line shown when the server says no |
| `components/auth/GoogleButton.tsx` | NEW | "Continue with Google". Does nothing yet, on purpose. |
| `components/auth/PasswordField.tsx` | NEW | Password box with Show / Hide |
| `components/TextField.tsx` | NEW | Labelled text box, for any form |
| `components/StarField.tsx`, `lib/star-field.ts` | NEW | The stars |
| `components/GlobeOrbit.tsx`, `lib/globe-orbit.ts` | NEW | The globe on sign up |
| `lib/plane-model.ts`, `lib/vec3.ts` | NEW | The plane's shape and 3D helpers, shared by the fly-by and the globe |
| `types/lock.ts` | NEW | `Lock` and `LockStatus` |
| `lib/locks.ts` | NEW | The one place locks are fetched (mock for now), what a lock is worth, status words |
| `lib/transaction-types.ts` | NEW | `Transaction`, the four types and their words. Safe to import in the browser. |
| `lib/transactions.ts` | NEW | Fetches transactions (mock for now). Server only. |
| `components/account/ActivityCard.tsx` | NEW | The Activity card |
| `components/account/TransactionTypeFilter.tsx` | NEW | The type drop-down |
| `components/locks/LockSummary.tsx` | NEW | The three totals on My locks |
| `components/locks/LockFilter.tsx` | NEW | All / Active / Exercised / Expired |
| `components/locks/LockRow.tsx` | NEW | One lock on My locks |
| `components/checkout/CheckoutHeader.tsx` | NEW | The checkout's header with the three steps |
| `components/trade/HeldLockCard.tsx` | NEW | "Your lock", with the Exercise button |
| `components/trade/ExerciseLock.tsx` | NEW | The Exercise button and its confirmation |
| `components/trade/LockOutcomeCard.tsx` | NEW | "How it ended" |
| `components/trade/LockTimelineCard.tsx` | NEW | The lock timeline |
| `components/trade/LockTermsCard.tsx` | NEW | Lock terms |
| `components/trade/LockNotes.tsx` | NEW | "If you don't exercise" and "Need help?" |
| `components/trade/FareTradeHero.tsx` | REPLACE | Takes the member's lock; chart key, ended state |
| `components/trade/FareTradeChart.tsx` | REPLACE | Passes the lock's position to the chart |
| `lib/fare-chart.ts` | REPLACE | Draws the purchase line and the locked-fare line |
| `components/trade/FareRangeCards.tsx` | REPLACE | Locked-fare tick; wording once the flight has left |
| `components/trade/FareTradeSkeleton.tsx` | REPLACE | Holds room for the "Back to" pill |
| `components/trade/LockStatusCard.tsx` | REPLACE | Takes the lock; says how an ended lock ended |
| `components/trade/LockTicket.tsx` | REPLACE | No booking buttons; shows the most a lock can pay |
| `components/trade/FeeDriversCard.tsx` | REPLACE | Link repointed to `/#pricing` |
| `lib/fares.ts` | REPLACE | Two more mock fares, for the ended mock locks |
| `lib/account.ts` | REPLACE | `getAccount()` takes its locks from `getLocks()` |
| `lib/placeholders.ts` | REPLACE | Adds `quoteHold` and `lockTaxes` |
| `components/Background.tsx` | REPLACE | Holds the stars |
| `components/PlaneFlyby.tsx`, `lib/plane-flyby.ts`, `lib/dither.ts` | REPLACE | Solid backdrop so stars do not show through the plane |
| `components/HeaderNav.tsx` | REPLACE | "How it works" removed |
| `components/Footer.tsx` | REPLACE | "How it works" points at `/#how-it-works`; solid background |
| `components/PillLink.tsx` | REPLACE | Adds `solidButtonClass` and `solidButtonSmallClass` |
| `components/landing/FareChart.tsx`, `PricingStory.tsx` | REPLACE | Links repointed; `id="pricing"` |

## Step 3A: route groups

1. **Move the site's pages** into `app/(site)/` with `git mv`, so history
   follows them. Skip any that update 01 already moved.

   ```bash
   mkdir -p "app/(site)"
   git mv app/page.tsx "app/(site)/page.tsx"
   git mv app/search   "app/(site)/search"
   git mv app/fares    "app/(site)/fares"
   git mv app/account  "app/(site)/account"
   git mv app/wallet   "app/(site)/wallet"
   ```

   Move any other page folder the repo has gained too, except log in and
   sign up (next step). Leave `app/layout.tsx`, `app/globals.css` and any
   icon or font files where they are.

2. **Move the team's log in folder**, which carries its `actions.ts` with it:

   ```bash
   mkdir -p "app/(auth)"
   git mv app/login "app/(auth)/login"
   ```

   If update 01 is applied there is already an `app/(auth)/login/` holding
   only update 01's `page.tsx`. Then move just the team's actions file in:
   `git mv app/login/actions.ts "app/(auth)/login/actions.ts"`, and deal with
   the team's `app/login/page.tsx` as in step 4. Afterwards `app/login/`
   must be gone: two pages answering `/login` stop the build. Remove the
   folder if it is left empty (`rmdir app/login`).

3. **Delete update 01's placeholder actions** if the file exists:
   `git rm "app/(auth)/actions.ts"`. The team's real actions replace it.

4. **The team's log in page.** This update's `app/(auth)/login/page.tsx`
   replaces it. Before overwriting, read the team's version and tell the user
   about anything in it that this page does not have (extra fields, a
   "remember me", a different redirect). Do not drop such things silently.

5. **The team's sign-up page.** Find it (search for where `register` is
   imported).
   - If it is at `/signup`, move its folder to `app/(auth)/signup` and let
     this update's page replace it, with the same care as for log in.
   - If it is at another address (say `/register`), stop and ask the user
     which address to keep. Whichever it is, there must be one sign-up page,
     and the `href="/signup"` in `app/(auth)/login/page.tsx` must point at it.

6. **Copy everything in `pages-route-groups/`** into `farelock/`:

   | File | | What it is |
   |---|---|---|
   | `app/layout.tsx` | REPLACE | The document and the background only. Header and footer move out. |
   | `app/(site)/layout.tsx` | NEW | Site header and footer |
   | `app/(auth)/layout.tsx` | NEW | Footer only |
   | `app/(checkout)/layout.tsx` | NEW | Footer only |
   | `app/not-found.tsx` | NEW | The 404 page. It renders the site header and footer itself. |
   | `app/(auth)/login/page.tsx` | REPLACE | Imports `logIn` from `./actions` |
   | `app/(auth)/signup/page.tsx` | NEW or REPLACE | Imports `register` from `../login/actions` |
   | `app/(site)/fares/[id]/page.tsx` | REPLACE | The three views |
   | `app/(site)/account/page.tsx` | REPLACE | Activity card; no Add funds pill |
   | `app/(site)/locks/page.tsx` | NEW | My locks |
   | `app/(checkout)/checkout/page.tsx`, `actions.ts` | NEW | Lock checkout |

7. **Fix imports of the moved actions.** Anything that imported
   `@/app/login/actions` must now import `@/app/(auth)/login/actions`:

   ```bash
   grep -rn "app/login/actions" app components lib
   ```

   (`app/(site)/account/page.tsx` in this update already uses the new path.)

8. **Clear the generated route types**, which still point at the old paths,
   and make them again. Skipping this gives type errors that look like the
   move broke something:

   ```bash
   rm -rf .next
   npx next typegen
   ```

9. Search the repo for text that still says `app/wallet/`, `app/login/` and
   so on (comments, docs, `FRONTEND_BRIEF.md`) and correct the paths.

## Step 3B: no move

1. **Copy everything in `pages-no-move/app/`** into `farelock/app/`:
   `account/page.tsx`, `fares/[id]/page.tsx`, `locks/page.tsx`,
   `checkout/page.tsx`, `checkout/actions.ts`, `login/page.tsx`,
   `signup/page.tsx`. The team's `app/login/actions.ts` stays exactly as it
   is.
2. **The team's log in and sign-up pages**: the same care as steps 4 and 5
   of 3A. Read theirs first, report differences, keep one sign-up address.
3. **If update 01 was applied this way**, delete what it left under
   `app/(auth)/` (`login/page.tsx`, `signup/page.tsx`, `actions.ts`): the
   pages now live at `app/login/` and `app/signup/`. Also delete the rule
   mentioning `data-auth-header` at the end of `app/globals.css`.
4. **Add the contents of `pages-no-move/globals.css.append.css`** to the end
   of `app/globals.css`.
5. Do not copy anything from `pages-route-groups/`.
6. `rm -rf .next && npx next typegen`, because pages were added.

## Step 4: check it

```bash
npx tsc --noEmit      # expect: nothing
npm run lint          # expect: only what was there before you started
npx next build        # expect: /login, /signup, /locks and /checkout in the route list
```

Then run it with the backend up (`npm run dev`; the frontend reads the
backend's address from `API_URL`, default `http://localhost:8000`) and look
at:

| Address | What you should see |
|---|---|
| `/` | Stars behind the whole page. Header: search bar and Log in, no "How it works". |
| `/signup` | Small header. Globe on the left (hidden below about 768px), card on the right. A rejected sign-up shows the backend's sentence and keeps everything typed except the password. A good one lands on `/account`. |
| `/login` | Small header, card in the middle. "Email or phone number" and "Password". A wrong password shows "That email, phone number or password isn't right." |
| `/account` | No "Add funds" pill beside "Find a fare". Four locks under "Your locks". Activity card with seven rows; picking a type changes the address to `?type=…` and the rows. |
| `/locks` | Totals 2, $14 and $138. Four rows. The filter pills change the address to `?show=…`. "Exercise for $14" opens the confirmation over the list. |
| `/fares/jfk-lis-2027-01-12-ma202` | Open lock, worth $14. Chart shows a dashed upright line on 30 Aug and a dashed level line at $590. Exercise button works. |
| `/fares/jfk-lis-2027-01-12-ma118` | Open lock, worth $0. Exercise greyed out, reason underneath. |
| `/fares/ewr-cdg-2026-12-20-sa880` | Ended lock, tag "Paid out". "How it ended" shows $138. No Exercise or Lock button anywhere. |
| `/fares/jfk-sfo-2026-09-30-ma417` | Ended lock, tag "Expired", paid $0. "Back to my locks". |
| `/fares/jfk-lis-2027-01-12-sa6252` | No lock: the ticket with "Lock this fare". |
| `/checkout?fare=jfk-lis-2027-01-12-sa6252` | Steps header. "Pay $19 and lock" is refused until the terms box is ticked, then returns to the fare page (nothing is bought yet). With under $19 in the wallet it shows "Add funds" instead. |
| `/locks`, `/account`, `/checkout` signed out | Redirect to `/login`. |
| `/anything-else` | 404 (with the site header and footer under option A). |

The four locks and seven transactions are mock data, the same for every
signed-in member. The wallet balance is real.

`previews/` has screenshots of how these looked when the update was built.

Do not commit or push unless the user asks.

## Where this differs from the wireframes

The user should know about these; each was a choice made while building.

- **Chart.** The wireframe put a "Lock bought" tag beside the purchase line.
  The line can be anywhere across the chart, and the tag covered the title or
  the fares depending on where it fell. The date and the locked fare are in
  the chart key in the corner instead.
- **Log in.** The field is "Email or phone number", because the team's
  `logIn` action sends an `identifier` that can be either.
- **Sign up.** The password hint is "8 to 72 characters" and the phone hint
  is "You can log in with it instead of your email": both taken from the
  team's actions, replacing two placeholders.
- **Checkout.** The wireframe's wording described the old product (cover
  against a rise, "book when you're ready"). It is rewritten for the current
  one: the lock pays when the fare falls, nothing is booked, and an open lock
  is exercised automatically at departure. A state for a wallet that cannot
  cover the fee was added.
- **Status words** come from one map (`lockStatusLabel` in `lib/locks.ts`):
  Active, Settling, Paid out, Expired. The fare page's tag for a lock the
  member exercised therefore reads "Paid out", where the wireframe said
  "Exercised".
- **A member whose lock on a fare has ended** sees the record view on that
  fare's page, and so cannot buy another lock on the same fare from it. That
  follows the rule that the ended view has nothing to buy. If re-locking
  should be possible, it needs a decision.

## Known and left as they are

- **Links that go nowhere yet**: `/terms`, `/privacy`, `/lock-terms`,
  `/support`. The Guidelines page was dropped; nothing links to it.
- **"Continue with Google"** and **"Download statement"** do nothing.
- **Landing page, footer tagline and page description** still describe the
  old product (cover against a rise, "Book when you're ready"). They need
  rewriting by whoever owns the copy. Places: `app/layout.tsx` (description),
  `components/Footer.tsx`, `components/Intro.tsx`, and in
  `components/landing/`: `Hero`, `HowItWorks`, `WorkedExample`,
  `PricingStory`, `Faq`. The account page's "Protecting fares now" and
  "Total saved" are the same kind of wording.
- **Phone sizes** have not been tuned. Nothing overflows at 390px wide, but
  the layout there is whatever the desktop design falls back to.
- **No withdraw button.** `withdraw` is a transaction type, but no page has
  a way to make one.

## Where the backend connects

Search the code for these markers. Each has the steps written under it.

| Marker | File | What goes there |
|---|---|---|
| `PLACEHOLDER` on `getLocks` | `lib/locks.ts` | The member's locks. Every page that shows a lock reads this one function. |
| `PLACEHOLDER` on the sums | `lib/locks.ts` | A lock's value should come from the backend's quote |
| `PROPOSED` | `types/lock.ts` | The shape of a lock, to agree with the backend |
| `PLACEHOLDER` on `getTransactions` | `lib/transactions.ts` | The member's transactions; pass the type through as a query parameter |
| `PROPOSED`, `LATER (status)` | `lib/transaction-types.ts` | The shape of a transaction; its statuses are shown as sent for now |
| `BACKEND (buy a lock)` | checkout `actions.ts` | Buy the lock from the wallet |
| `LATER (exercise)` | `components/trade/ExerciseLock.tsx` | Exercise the lock; hold the payout while the dialog is open |
| `LATER (taxes)` | checkout `page.tsx` | Whether a lock fee carries taxes |
| `LATER (Google sign-in)` | `components/auth/GoogleButton.tsx` | Start the Google flow |
| `LATER (statement)` | `components/account/ActivityCard.tsx` | The statement download |
| `LATER (fare updates)` | `components/trade/FareTradeHero.tsx` | Refreshing the live fare |
| `getFare` comment | `lib/fares.ts` | A fare must stay fetchable after its flight departs while a lock on it exists, or the lock's page has nothing to show |
| `TBD.*` | `lib/placeholders.ts` | Facts the product has not decided: refund terms, hold time, taxes |

Two things the backend must guarantee for the chart to be right: the fare
history has to reach back to the day the lock was bought, and the locked fare
has to equal the history's fare on that day. Otherwise the purchase mark has
nowhere to sit, or floats off the line.
