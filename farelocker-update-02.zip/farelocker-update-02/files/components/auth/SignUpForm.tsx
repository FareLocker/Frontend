"use client";

import Link from "next/link";
import { solidButtonClass } from "@/components/PillLink";
import TextField from "@/components/TextField";
import { useAuthForm, type AuthAction } from "./authForm";
import FormError from "./FormError";
import GoogleButton from "./GoogleButton";
import PasswordField from "./PasswordField";

/**
 * The sign up form: Google, or first and last name, email, an optional phone
 * number and a password.
 *
 * `action` is the team's `register` server action; the page passes it in.
 * The field names (first_name, last_name, email, phone_number, password) are
 * the ones that action reads and sends to the backend's /auth/register.
 */
export default function SignUpForm({ action }: { action: AuthAction }) {
  const { error, values, formAction, pending } = useAuthForm(action);

  return (
    <form action={formAction} className="flex flex-col gap-5">
      <GoogleButton />
      {error ? <FormError>{error}</FormError> : null}
      {/* Side by side; each drops to its own row when the card gets narrow. */}
      <div className="flex flex-wrap gap-x-3 gap-y-5">
        <div className="min-w-0 flex-1 basis-[150px]">
          <TextField
            label="First name"
            name="first_name"
            autoComplete="given-name"
            defaultValue={values.first_name}
            required
          />
        </div>
        <div className="min-w-0 flex-1 basis-[150px]">
          <TextField
            label="Last name"
            name="last_name"
            autoComplete="family-name"
            defaultValue={values.last_name}
            required
          />
        </div>
      </div>
      <TextField
        label="Email"
        name="email"
        type="email"
        autoComplete="email"
        placeholder="you@example.com"
        defaultValue={values.email}
        required
      />
      <TextField
        label="Phone number"
        name="phone_number"
        type="tel"
        autoComplete="tel"
        placeholder="+1 555 0100"
        defaultValue={values.phone_number}
        optional
        hint="You can log in with it instead of your email."
      />
      {/* 8 to 72 is the backend's rule; see the 422 message in the actions. */}
      <PasswordField
        autoComplete="new-password"
        minLength={8}
        maxLength={72}
        hint="8 to 72 characters."
      />
      <button
        type="submit"
        disabled={pending}
        className={`${solidButtonClass} w-full disabled:cursor-wait disabled:opacity-60`}
      >
        {pending ? "Creating your account…" : "Create account"}
      </button>
      <p className="text-center text-xs leading-normal text-muted">
        By creating an account you agree to the{" "}
        <Link href="/terms" className="text-foreground underline underline-offset-2">
          Terms
        </Link>{" "}
        and{" "}
        <Link href="/privacy" className="text-foreground underline underline-offset-2">
          Privacy policy
        </Link>
        .
      </p>
    </form>
  );
}
