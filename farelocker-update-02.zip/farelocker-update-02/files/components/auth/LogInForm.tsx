"use client";

import { solidButtonClass } from "@/components/PillLink";
import TextField from "@/components/TextField";
import { useAuthForm, type AuthAction } from "./authForm";
import FormError from "./FormError";
import GoogleButton from "./GoogleButton";
import PasswordField from "./PasswordField";

/**
 * The log in form: Google, or email (or phone number) and password.
 *
 * `action` is the team's `logIn` server action. The page passes it in, so
 * this file does not need to know where the actions live. The field names
 * (identifier, password) are the ones that action reads.
 */
export default function LogInForm({ action }: { action: AuthAction }) {
  const { error, values, formAction, pending } = useAuthForm(action);

  return (
    <form action={formAction} className="flex flex-col gap-5">
      <GoogleButton />
      {error ? <FormError>{error}</FormError> : null}
      <TextField
        label="Email or phone number"
        name="identifier"
        autoComplete="username"
        defaultValue={values.identifier}
        required
      />
      <PasswordField autoComplete="current-password" />
      <button
        type="submit"
        disabled={pending}
        className={`${solidButtonClass} w-full disabled:cursor-wait disabled:opacity-60`}
      >
        {pending ? "Logging in…" : "Log in"}
      </button>
    </form>
  );
}
