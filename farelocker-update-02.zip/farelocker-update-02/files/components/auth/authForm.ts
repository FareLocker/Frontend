"use client";

import { useActionState } from "react";

/**
 * A log in or sign up server action, in the shape the team's actions have
 * (logIn and register in the login folder's actions.ts): it is handed the
 * form, and returns a sentence to show if it failed. On success it redirects
 * and never returns.
 */
export type AuthAction = (
  state: { error: string } | null,
  formData: FormData,
) => Promise<{ error: string } | null>;

/**
 * Runs an auth action from a form.
 *
 *   const { error, values, formAction, pending } = useAuthForm(action);
 *   <form action={formAction}> ... <input name="email" defaultValue={values.email} />
 *
 * React empties a form once its action has run, so after a failed attempt
 * everything typed would be gone. This keeps what was typed (never the
 * password) and hands it back as `values` to put in the boxes again.
 */
export function useAuthForm(action: AuthAction) {
  const [state, formAction, pending] = useActionState(
    async (
      _previous: { error: string; values: Record<string, string> } | null,
      formData: FormData,
    ) => {
      const result = await action(null, formData);
      if (!result) return null;
      const values: Record<string, string> = {};
      formData.forEach((value, name) => {
        if (typeof value === "string" && name !== "password") values[name] = value;
      });
      return { error: result.error, values };
    },
    null,
  );

  return {
    error: state?.error ?? null,
    values: state?.values ?? {},
    formAction,
    pending,
  };
}
